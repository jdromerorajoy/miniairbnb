# MiniAirbnb

Integrantes:
    - Carrizo, Santiago
    - Corrales, Lucia
    - Fernandez Piussi, Franco

Setup:

pip install -r requirements.txt

Users:

-superuser:
    user: admin
    pass: admin


Logueese como Owner para ver las reservas de sus propiedades:

-owners: <br/>
    user: carlosdiaz  /  pass: charly2019  (Reservas precargadas) <br/>
    user: julianmiguez  /  pass: juli2019   (Reservas precargadas) <br/>
    user: claudiacordoba  /  pass: clau2019  (Reservas precargadas) <br/>
    user: francopiussi  /  pass: fran2019 <br/>
    user: santiagocarrizo  /  pass: santi2019 <br/>
    user: luciacorrales  /  pass: luci2019
